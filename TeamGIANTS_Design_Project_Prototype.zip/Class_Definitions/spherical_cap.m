classdef spherical_cap < capacitor
    
    
end